//Author(s): Tudor Marinescu, William Davidson, Thomas Davidson
//Capstone Encoder
//Date: June 14th, 2020

#include "main.h"
#include "HAL_GPIO.h"
#include "HAL_TIM4.h"
#include "HAL_CLK.h"
#include "interrupts.h"
#include "dev.h"
#include "HAL_UART1.h"
#include "HAL_CAN.h"
#include "HAL_I2C.h"

//Used for a makeshift SysTick timer for a delay function
#define TIM4_PERIOD 124

//Delay in milliseconds
void Delay(uint32_t n)
{
	SetTimerTick(n);
	while(GetTimerTick() != 0);
}

uint32_t main(void)
{
	/*CLK Config*/
	CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
	CLK_ClockSwitchConfig(CLK_SWITCHMODE_AUTO, CLK_SOURCE_HSE, 0, CLK_CURRENTCLOCKSTATE_DISABLE);
	
	/*TIM4 Config*/
	TIM4_TimeBaseInit(TIM4_PRESCALER_128, TIM4_PERIOD);
	TIM4_ClearFlag(TIM4_FLAG_UPDATE);
	TIM4_ITConfig(TIM4_IT_UPDATE, 1);
	TIM4_Cmd(1);

	/*UART1 Config*/
	UART1_Init(9600, UART1_WORDLENGTH_8D, UART1_STOPBITS_1, UART1_PARITY_NO, UART1_SYNCMODE_CLOCK_DISABLE, UART1_MODE_TXRX_ENABLE);
	UART1_ClearFlag(UART1_FLAG_RXNE);
	UART1_Cmd(1);
	
	/*CAN Config*/
	CAN_Init(CAN_MasterCtrl_AllDisabled, CAN_Mode_Normal, CAN_SynJumpWidth_1TimeQuantum, CAN_BitSeg1_8TimeQuantum, CAN_BitSeg2_7TimeQuantum, 2); //500kbit/s
	CAN_FilterInit(CAN_FilterNumber_0, 1, CAN_FilterMode_IdMask, CAN_FilterScale_32Bit, 0, 0, 0, 0, 0, 0, 0, 0);
	CAN_TTComModeCmd(1);

	/*I2C Config*/
	I2C_Init(I2C_MAX_FAST_FREQ, 0, I2C_DUTYCYCLE_2, I2C_ACK_CURR, I2C_ADDMODE_7BIT, I2C_MAX_INPUT_FREQ);
	I2C_Cmd(1);

	//Enable all interrupts
	enableInterrupts();
	
	/*GPIO Config*/
	GPIO_Init(GPIO_LD3, PIN_LD3, GPIO_MODE_OUT_PP_LOW_SLOW);
	GPIO_Init(GPIO_LD4, PIN_LD4, GPIO_MODE_OUT_PP_LOW_SLOW);
	GPIO_Init(GPIO_LD5, PIN_LD5, GPIO_MODE_OUT_PP_LOW_SLOW);
	GPIO_Init(GPIO_LD6, PIN_LD6, GPIO_MODE_OUT_PP_LOW_SLOW);
	GPIO_Init(GPIO_LD7, PIN_LD7, GPIO_MODE_OUT_PP_LOW_SLOW);
	GPIO_Init(GPIOA, GPIO_PIN_4, GPIO_MODE_OUT_OD_HIZ_FAST); //For UART (not needed, architecture handles it by itself)
	GPIO_Init(GPIOA, GPIO_PIN_5, GPIO_MODE_OUT_OD_HIZ_FAST); //For UART (not needed, architecture handles it by itself)
	GPIO_Init(GPIO_BTN1, PIN_BTN1, GPIO_MODE_IN_FL_NO_IT);
	GPIO_Init(GPIO_BTN2, PIN_BTN2, GPIO_MODE_IN_FL_NO_IT);
	
	while(1)
	{
		/*if(GPIO_ReadInputPin(GPIO_BTN1, PIN_BTN1) == 0x1)
		{
			GPIO_WriteHigh(GPIO_LD3, PIN_LD3);
			GPIO_WriteHigh(GPIO_LD4, PIN_LD4);
			GPIO_WriteHigh(GPIO_LD5, PIN_LD5);
			GPIO_WriteHigh(GPIO_LD6, PIN_LD6);
			GPIO_WriteHigh(GPIO_LD7, PIN_LD7);
		}
		else
		{
			GPIO_WriteLow(GPIO_LD3, PIN_LD3);
			GPIO_WriteLow(GPIO_LD4, PIN_LD4);
			GPIO_WriteLow(GPIO_LD5, PIN_LD5);
			GPIO_WriteLow(GPIO_LD6, PIN_LD6);
			GPIO_WriteLow(GPIO_LD7, PIN_LD7);
		}*/
		
		GPIO_WriteReverse(GPIO_LD3, PIN_LD3);
		GPIO_WriteReverse(GPIO_LD4, PIN_LD4);
		GPIO_WriteReverse(GPIO_LD5, PIN_LD5);
		GPIO_WriteReverse(GPIO_LD6, PIN_LD6);
		GPIO_WriteReverse(GPIO_LD7, PIN_LD7);
		UART1_SendData8(0xEF);
		UART1_SendBreak();
		Delay(1000);
	}
}
